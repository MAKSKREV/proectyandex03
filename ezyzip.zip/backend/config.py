import os
import datetime

basedir = os.path.abspath(os.path.dirname(__file__))

class DefaultConfig:
    """
    Default Configuration
    """
    APP_NAME = os.environ.get('APP_NAME')
    SECRET_KEY = os.environ.get('SECRET_KEY', "d7da6e940725de5a15b7e48f5a71f535a315c72a5372c1d3bb8691b38b5f29a1")
    PROPAGATE_EXCEPTIONS = True
    DEBUG = False
    TESTING = False

    API_TITLE = "Движение Первых | ТехноДвиж 2023 | API"
    API_VERSION = "v2"
    OPENAPI_VERSION = "3.0.3"
    OPENAPI_URL_PREFIX = "/"
    OPENAPI_SWAGGER_UI_PATH = "/swagger-ui"
    OPENAPI_SWAGGER_UI_URL = "https://cdn.jsdelivr.net/npm/swagger-ui-dist/"

    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SHOW_SQLALCHEMY_LOG_MESSAGES = False

    APP_ENV_LOCAL = 'local'
    APP_ENV_TESTING = 'testing'
    APP_ENV_DEVELOP = 'develop'
    APP_ENV_PRODUCTION = 'production'
    APP_ENV = ''

    DATE_FMT = '%Y-%m-%d %H:%M:%S'
    LOG_FILE_API = f'{basedir}/logs/api.log'


class DevelopConfig(DefaultConfig):
    APP_ENV = DefaultConfig.APP_ENV_DEVELOP
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:pswwdpost@localhost:5432/texnodvzh_db'

class TestingConfig(DefaultConfig):
    APP_ENV = DefaultConfig.APP_ENV_TESTING
    TESTING = True
    DEBUG = True 
    WTF_CSRF_ENABLED = False
    LOG_FILE_API = f'{basedir}/logs/api_tests.log'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_TEST_URL')


class LocalConfig(DefaultConfig):
    APP_ENV = DefaultConfig.APP_ENV_LOCAL
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')


class ProductionConfig(DefaultConfig):
    APP_ENV = DefaultConfig.APP_ENV_PRODUCTION
    HOST = '0.0.0.0'
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'postgresql://postgres:pswwdpost@localhost:5432/texnodvizh_db'
