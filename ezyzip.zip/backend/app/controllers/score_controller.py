import logging
from app.services import score_service
from flask.views import MethodView
from flask_smorest import Blueprint
from flask_principal import Permission, RoleNeed
from app.schemas.score_shema import *

logger = logging.getLogger(__name__)

write_permission = Permission(RoleNeed('write'))

blp = Blueprint("Score", __name__, description="Score API")

@blp.route("/scores")
class ScoresList(MethodView):  
    @blp.response(200, ScoresSchema(many=True))
    def get(self):
        result = score_service.get_all_score_tabels()
        return result

@blp.route("/score/new")
class ScoreNew(MethodView):
    @write_permission.require(http_exception=403)
    @blp.arguments(ScoreSchema)
    def post(self, score_data):
        result = score_service.new_score(score_data)
        return result

@blp.route("/score/<int:score_id>")
class Score(MethodView):  
    @blp.response(200, ScoreSchema)
    def get(self, score_id):
        result = score_service.get_score(score_id)
        return result

@blp.route("/score/<int:score_id>/team/<int:team>/score/<int:score_new>")
class ScoreUpdate(MethodView):  
    @write_permission.require(http_exception=403)
    @blp.response(200, ScoreUpdateSchema)
    def post(self, score_id, team, score_new):
        result = score_service.update_score(score_id, team, score_new)
        return result
