from flask_smorest import Api
from app.controllers.score_controller import blp as ScoreBlueprint


def register_routing(app):
    api = Api(app)
    api.register_blueprint(ScoreBlueprint)
