from flask_migrate import Migrate
from flask_cors import CORS
from flask_principal import Principal

migrate = Migrate()
cors = CORS()
principal = Principal()
