from app.db import db

class ScoreModel(db.Model):
    __tablename__ = "score"
    
    id = db.Column(db.Integer, primary_key=True) 
    
    name_team_1 = db.Column(db.String(), nullable=False)
    name_team_2 = db.Column(db.String(), nullable=False)
    
    score_team_1 = db.Column(db.INT, nullable=False, default=0)
    score_team_2 = db.Column(db.INT, nullable=False, default=0)
    score_teams = db.Column(db.INT, nullable=False, default=0)
    
    timer = db.Column(db.Boolean, nullable=False, default=0)
    timer_start = db.Column(db.TIMESTAMP, nullable=False, default=0)
    timer_end = db.Column(db.TIMESTAMP, nullable=False, default=0)
    
    team_1_score_street_1 = db.Column(db.INT, nullable=False, default=0)
    team_1_score_street_2 = db.Column(db.INT, nullable=False, default=0)
    team_1_score_street_3 = db.Column(db.INT, nullable=False, default=0)
    
    team_2_score_street_1 = db.Column(db.INT, nullable=False, default=0)
    team_2_score_street_2 = db.Column(db.INT, nullable=False, default=0)
    team_2_score_street_3 = db.Column(db.INT, nullable=False, default=0)
    
    team_score_street_main = db.Column(db.INT, nullable=False, default=0)
    progress_bar_state = db.Column(db.INT, nullable=False, default=0)

    final_winner = db.Column(db.String(), nullable=False)
    state_of_vidget = db.Column(db.INT, nullable=False, default=0)
    final_winner_score = db.Column(db.INT, nullable=False, default=0)
