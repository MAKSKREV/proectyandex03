from app.db import db

from app.models.score_model import ScoreModel
from app.models.role_model import RoleModel
from app.models.blocklist_model import BlocklistModel

from datetime import datetime
from passlib.hash import pbkdf2_sha256
from sqlalchemy import asc

from flask import current_app
from flask_principal import identity_changed, Identity
from flask_jwt_extended import create_access_token, create_refresh_token, get_jwt_identity, get_jwt
from flask_smorest import abort

from app.services import user_role_service


def get_all_score_tabels():
    results = ScoreModel.query.order_by(asc(ScoreModel.id)).all()
    return results


def new_score(score_data):
    new_name_team_1 = score_data["name_team_1"]
    new_name_team_2 = score_data["name_team_2"]
    new_score_team_1 = score_data["score_team_1"]
    new_score_team_2 = score_data["score_team_2"]

    new_score = ScoreModel(name_team_1 = new_name_team_1, name_team_2 = new_name_team_2, score_team_1 = new_score_team_1, score_team_2 = new_score_team_2)

    try:
        db.session.add(new_score)
        db.session.commit()
    
    except:
        db.session.rollback()
        abort(400, message="Can not create new!")
        
    return {"message": "Register successfully!"}


def get_score(score_id):
    results = ScoreModel.query.filter_by(id=score_id).first()
    return results


def update_score(score_id, team, score_new):
    score = ScoreModel.query.filter_by(id=score_id).first()
    if not score:
        abort(400, message="Score doesn't exist, cannot update!")

    try:
        if team == 1:
            score.score_team_1 = score_new
        elif team == 2:
            score.score_team_2 = score_new  
        db.session.commit()
    except:
        db.session.rollback()
        abort(400, message="Can not update!")

    return score