from marshmallow import Schema, fields

class ScoreSchema(Schema):
    id = fields.Str(dump_only=True)
    name_team_1 = fields.Str(required=True)
    name_team_2 = fields.Str(required=True)
    score_team_1 = fields.Str(required=True)
    score_team_2 = fields.Str(required=True)
    score_teams = fields.Str(required=True)

class ScoresSchema(Schema):    
    id = fields.Str(dump_only=True)
    
    name_team_1 = fields.Str(required=True)
    name_team_2 = fields.Str(required=True)
    
    score_team_1 = fields.Int(required=True)
    score_team_2 = fields.Int(required=True)
    score_teams = fields.Int(required=True)
    
    timer = fields.Boolean(required=True)
    timer_start = fields.DateTime(required=True) 
    timer_end = fields.DateTime(required=True) 
    
    team_1_score_street_1 = fields.Int(required=True)
    team_1_score_street_2 = fields.Int(required=True)
    team_1_score_street_3 = fields.Int(required=True)
    
    team_2_score_street_1 = fields.Int(required=True)
    team_2_score_street_2 = fields.Int(required=True)
    team_2_score_street_3 = fields.Int(required=True)
    
    team_score_street_main = fields.Int(required=True)
    progress_bar_state = fields.Int(required=True)
    final_winner = fields.Str(required=True)
    state_of_vidget = fields.Int(required=True)
    final_winner_score = fields.Int(required=True)    
class ScoreUpdateSchema(Schema):
    id = fields.Str(dump_only=True)
    name_team_1 = fields.Str(required=True)
    name_team_2 = fields.Str(required=True)
    score_team_1 = fields.Str(required=True)
    score_team_2 = fields.Str(required=True)
    score_teams = fields.Str(required=True)
