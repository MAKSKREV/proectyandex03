from app import db
import click

def create_db():
    db.create_all()
    db.session.commit()
    
def reset_db():
    db.drop_all()
    db.create_all()
    db.session.commit()
    
def drop_db():
    db.drop_all()
    db.session.commit()

def init_app(app):
    if app.config['APP_ENV'] == 'production':
        commands = [create_db, reset_db, drop_db]
    else:
        commands = [create_db, reset_db, drop_db]

    for command in commands:
        app.cli.add_command(app.cli.command()(command))
