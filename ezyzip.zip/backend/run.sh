#!/bin/bash
export APP_SETTINGS_MODULE=config.ProductionConfig
flask run -h 0.0.0.0
